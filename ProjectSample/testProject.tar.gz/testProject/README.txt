This project is IM core server project.
Start this core server, basic IM client communcation works.

1.To build this project,just run make in current dictionary.
2.Server just tested on Ubuntu,it works on ubuntu 12.04
3.After build successfully,ELF file achieved at ./bin.
Just cd ./bin and run.
4.Config server,just cd ./config,and modify the config file.
5.If u want to read run time log,just cd ./log
