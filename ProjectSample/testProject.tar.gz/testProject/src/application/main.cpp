#include <iostream>
#include "businessLogic/b.h"

int main()
{
    std::cout << add() << std::endl;
    return 0;
}
